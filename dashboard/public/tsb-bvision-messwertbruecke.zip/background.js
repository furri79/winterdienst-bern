const DASH='https://winterdienst-dashboard-tsb.michel-furrer927704.chatgpt.site';
const BV=['https://www.bvision.digital/*','https://bvision.digital/*'];
const INTERVAL=15*60*1000;
const SAFE_KEYS=['data','error','last_attempt','cloud_error','cloud_uploaded_at'];
let busy=false;
const origin=url=>{try{return new URL(url).origin}catch{return ''}};
async function safeState(){return chrome.storage.local.get(SAFE_KEYS);}
async function sendToDashboards(payload){
 const tabs=await chrome.tabs.query({url:DASH+'/*'});
 await Promise.allSettled(tabs.map(t=>chrome.tabs.sendMessage(t.id,{type:'TSB_UPDATE',...payload})));
}
async function upload(data){
 const {cloud_upload_token:token}=await chrome.storage.local.get('cloud_upload_token');
 if(!token)return {cloud_error:'Online-Übertragung noch nicht aktiviert. Im übertragenden PC-/NAS-Browser aktivieren.'};
 try{
  const response=await fetch(DASH+'/api/bvision',{method:'POST',headers:{'Content-Type':'application/json','Authorization':'Bearer '+token},body:JSON.stringify(data),cache:'no-store',credentials:'omit',redirect:'error',signal:AbortSignal.timeout(15000)});
  if(!response.ok)throw Error(response.status===401?'Online-Verbindung abgelaufen. Im übertragenden PC-/NAS-Browser erneut aktivieren.':'Online-Upload fehlgeschlagen (HTTP '+response.status+').');
  const ack=await response.json();if(!ack.ok)throw Error('Online-Upload nicht bestätigt.');
  await chrome.alarms.clear('tsb-cloud-retry');return {cloud_error:'',cloud_uploaded_at:Date.now()};
 }catch(error){await chrome.alarms.create('tsb-cloud-retry',{delayInMinutes:1});return {cloud_error:error.message};}
}
async function collect(force=false){
 if(busy)return;
 const previous=await safeState();
 if(!force && previous.last_attempt && Date.now()-previous.last_attempt<INTERVAL){await sendToDashboards(previous);return;}
 busy=true;
 try{
  const tabs=await chrome.tabs.query({url:BV});
  let data,error='Bvision-Tab fehlt. Station Mosaik → Spalten im angemeldeten Browser öffnen.';
  const stations={};let updated=0;
  for(const tab of tabs){
   try{
    const answer=await chrome.tabs.sendMessage(tab.id,{type:'TSB_READ'});
    if(answer?.data?.stations){
     for(const [key,item] of Object.entries(answer.data.stations)){
      const observed=Date.parse(item.observed_at);
      if(Number.isFinite(observed)&&(!stations[key]||observed>Date.parse(stations[key].observed_at)))stations[key]=item;
     }
     const stamp=Date.parse(answer.data.updated_at);if(Number.isFinite(stamp))updated=Math.max(updated,stamp);
    }
    if(answer?.error)error=answer.error;
   }
   catch{error='Bvision-Tab nach Installation einmal neu laden und Stationsübersicht öffnen.';}
  }
  if(Object.keys(stations).length&&updated)data={updated_at:new Date(updated).toISOString(),stations};
  const payload={...previous,last_attempt:Date.now(),error:data?'':error,...(data?{data}:{}),...(data?await upload(data):{})};
  await chrome.storage.local.set(payload);await sendToDashboards(payload);
 }finally{busy=false;}
}
async function setup(){
 await chrome.storage.local.setAccessLevel({accessLevel:'TRUSTED_CONTEXTS'});
 await chrome.alarms.clear('tsb-30min');
 if(!await chrome.alarms.get('tsb-15min'))await chrome.alarms.create('tsb-15min',{periodInMinutes:15,delayInMinutes:15});
}
chrome.runtime.onInstalled.addListener(()=>{setup();collect(true);});
chrome.runtime.onStartup.addListener(()=>{setup();collect(true);});
chrome.alarms.onAlarm.addListener(a=>{if(['tsb-15min','tsb-cloud-retry'].includes(a.name))collect(true);});
chrome.runtime.onMessage.addListener((m,sender,respond)=>{
 if(sender.id!==chrome.runtime.id)return;
 const from=origin(sender.url);
 if(m?.type==='TSB_SET_CLOUD_KEY' && from===DASH){
  if(typeof m.upload_token!=='string'||!/^[A-Za-z0-9_-]{32,100}$/.test(m.upload_token)){respond({error:'Ungültige Übertragungskonfiguration.'});return;}
  (async()=>{await setup();await chrome.storage.local.set({cloud_upload_token:m.upload_token});await collect(true);const state=await safeState();respond({ok:true,error:state.cloud_error||state.error||''});})().catch(()=>respond({error:'Online-Verbindung konnte nicht gespeichert werden.'}));return true;
 }
 if(m?.type==='TSB_DASHBOARD_REFRESH' && from===DASH){
  (async()=>{await collect(true);respond(await safeState());})().catch(()=>respond({error:'Aktualisierung der Messstellen fehlgeschlagen.'}));return true;
 }
 if(m?.type==='TSB_DASHBOARD_READY' && from===DASH){
  (async()=>{await setup();respond(await safeState());await collect(false);})().catch(()=>respond({error:'Messwertbrücke konnte nicht gestartet werden.'}));return true;
 }
 if(m?.type==='TSB_SOURCE_READY' && ['https://www.bvision.digital','https://bvision.digital'].includes(from)){
  (async()=>{const p=await safeState();await collect(Boolean(p.error));respond({ok:true});})().catch(()=>respond({ok:false}));return true;
 }
});
setup();
