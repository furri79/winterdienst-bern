function publish(payload){window.postMessage({type:'TSB_EXTENSION_DATA',payload},location.origin);}
chrome.runtime.onMessage.addListener((m,sender)=>{
  if(sender.id===chrome.runtime.id && m?.type==='TSB_UPDATE')publish(m);
});
function ready(force=false){chrome.runtime.sendMessage({type:force?'TSB_DASHBOARD_REFRESH':'TSB_DASHBOARD_READY'}).then(publish).catch(()=>{});}
ready(true);
window.addEventListener('pageshow',()=>ready(true));
setInterval(ready,30000);

window.addEventListener('message',event=>{
  if(event.source===window && event.origin===location.origin && event.data?.type==='TSB_CONFIGURE_CLOUD'){
    chrome.runtime.sendMessage({type:'TSB_SET_CLOUD_KEY',upload_token:event.data.upload_token}).then(result=>window.postMessage({type:'TSB_CLOUD_STATUS',error:result.error||''},location.origin)).catch(()=>window.postMessage({type:'TSB_CLOUD_STATUS',error:'Neue Messwertbrücke bitte installieren und Dashboard neu laden.'},location.origin));return;
  }
  if(event.source!==window || event.origin!==location.origin || event.data?.type!=='TSB_REFRESH_REQUEST')return;
  chrome.runtime.sendMessage({type:'TSB_DASHBOARD_REFRESH'}).then(publish).catch(()=>{});
});
