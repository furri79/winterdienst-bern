chrome.runtime.onMessage.addListener((message,sender,respond)=>{
  if(sender.id!==chrome.runtime.id || message?.type!=='TSB_READ') return;
  if(!location.hash.startsWith('#/station-modules/columns')){
    respond({error:'Bvision: Station Mosaik → Spalten öffnen und Filter auf Alle setzen.'}); return;
  }
  const data=tsbExtract(document);
  respond(Object.keys(data.stations).length>0 ? {data} : {error:'Keine freigegebene Messstelle sichtbar. Filter auf Alle setzen und Anmeldung prüfen.'});
});
// After load or a SPA navigation, offer a fresh reading, rate limited by worker.
setTimeout(()=>chrome.runtime.sendMessage({type:'TSB_SOURCE_READY'}).catch(()=>{}),3000);
window.addEventListener('hashchange',()=>setTimeout(()=>chrome.runtime.sendMessage({type:'TSB_SOURCE_READY'}).catch(()=>{}),1500));
