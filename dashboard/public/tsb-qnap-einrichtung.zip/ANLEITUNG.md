# TSB: Boschung mit QNAP statt PC

Vorbereitet für Intel Celeron J1900 / 2 GB RAM / QTS 5.2 und vorhandene Container Station. Auf deinem NAS noch nicht getestet oder gestartet. Ein zusätzlicher Cloudserver ist für diese Variante nicht nötig. Das NAS muss eingeschaltet und mit dem Internet verbunden bleiben.

## 1. Paket ablegen

ZIP am PC entpacken. In QNAP File Station in der Freigabe «Container» den Ordner «tsb-bvision» anlegen. Den Inhalt des entpackten Pakets dorthin kopieren. Im Ordner muss «extension» direkt sichtbar sein, ohne weitere ZIP-Unterordner.

Den vollständigen Pfad prüfen. Normalerweise lautet er `/share/Container/tsb-bvision`. Bei einer anderen Freigabe entsprechend anpassen. Für diesen Ordner genügt Lesezugriff für den Container. Keine allgemeinen NAS-Berechtigungen erweitern.

## 2. Anwendung in Container Station erstellen

Die Datei «einrichtung.html» auf dem eigenen PC im Browser öffnen. NAS-IP, Ordnerpfad und ein neues Passwort für die Browseroberfläche eingeben. Das ist kein Bvision-Passwort. Diese Eingaben werden nur lokal zur Erstellung der Vorlage verwendet.

Container Station öffnen → Anwendungen → Erstellen. Namen «tsb-bvision» verwenden, erzeugte YAML-Vorlage einfügen, validieren und starten. Je nach Container-Station-Version heissen die Schaltflächen etwas anders. Das Image «lscr.io/linuxserver/chromium» wird beim ersten Start heruntergeladen.

Die Vorlage enthält das selbst gewählte Browser-Passwort. Sie gehört ausschliesslich auf das eigene NAS und nicht in ein öffentliches Repository oder diesen Chat.

Deine Container Station lehnt CPU- und RAM-Grenzen in der YAML ab. Die korrigierte Vorlage lässt «mem_limit» und «cpus» deshalb weg. Unter «Advanced Settings / Erweiterte Einstellungen» in Container Station das RAM-Limit auf 1024 MB setzen und, wenn angeboten, einen CPU-Kern auswählen. Ohne diese manuelle Einstellung besteht kein RAM-Limit aus der Vorlage. Wenn diese Einstellungen im Anwendungsdialog fehlen, vor dem Dauerbetrieb den nächsten Dialog prüfen; eine vorhandene Anwendung nicht auf Verdacht löschen. Der gemeinsam genutzte Speicher ist in der Vorlage auf 512 MB begrenzt. Die Einstellungen begrenzen die Last, garantieren aber keinen stabilen Browserbetrieb mit 2 GB Gesamtspeicher. Bei Speicherfehlern oder laufenden Neustarts: Container stoppen und freien Speicher prüfen; nicht einfach alle Limits entfernen. Im Ressourcenmonitor beobachten, ob das NAS stark auslagert.

## 3. Browser auf dem NAS öffnen

Im Heim-/Betriebsnetz `https://NAS-IP:3081` öffnen. Für das lokale, selbst signierte Zertifikat muss der Browser eine Ausnahme erhalten; vorher IP und Zielgerät prüfen. Benutzer «tsb», Passwort aus Schritt 2.

Nur der HTTPS-Port wird an die angegebene lokale NAS-Adresse gebunden. Keine Router-Portfreigabe, kein UPnP und keine Veröffentlichung über myQNAPcloud für diesen Browser einrichten. Die Browseroberfläche ermöglicht Zugriff auf die dort gespeicherten Anmeldungen und darf nur dem Eigentümer zugänglich sein.

Im angezeigten Chromium `chrome://extensions` öffnen. Prüfen, ob «TSB Bvision Messwertbrücke» geladen und aktiviert ist. Falls nicht: Entwicklermodus aktivieren → Entpackte Erweiterung laden → `/opt/tsb-extension` wählen. Es ist die vorhandene Messwertbrücke, kein neuer Boschung-Zugang.

## 4. Einmal anmelden und verbinden

Im NAS-Chromium `https://bvision.digital/` öffnen und selbst bei Bvision anmelden. Eine Anmeldung vom PC wird nicht automatisch übernommen. «Station Mosaik → Spalten» aufrufen, Filter «Alle». Gewünschte Messstellen sichtbar halten: Bern: Riedbach, Schwarzenburgstrasse und Melchenbühlweg; Blatten bei Naters: Gamsenbrücke Principal; Meikirch: Meikirch. Nur vorhandene, eindeutig zugeordnete Karten werden übertragen. Diesen Tab offen lassen.

In einem zweiten Tab desselben NAS-Chromium das Dashboard öffnen:

https://winterdienst-dashboard-tsb.michel-furrer927704.chatgpt.site

Unten «Administratorenbereich → PC / NAS → Dashboard verbinden» öffnen und «Übertragung aktivieren» wählen. Hier wird der NAS-Browser verbunden. Falls verlangt, mit dem Eigentümerkonto anmelden. Bestätigung der Online-Übertragung abwarten. Anschliessend kann der Dashboard-Tab geschlossen werden. Den Bvision-Tab und den NAS-Browser nicht schliessen, sondern nur den äusseren Fernzugriffs-Tab am PC.

Das Browserprofil mit Anmeldung und Upload-Verbindung bleibt im Docker-Volume «tsb_browser_profile» erhalten. Kein Bvision-Passwort wird in die Vorlage, die Webseite oder das Repository geschrieben. Das Profil und eventuelle NAS-Sicherungen davon enthalten private Sitzungsdaten; nur für den Eigentümer freigeben. Beim Entfernen der Anwendung das Volume nicht löschen, wenn die Anmeldung erhalten bleiben soll.

## 5. Betrieb wirklich prüfen

1. Auf dem iPhone das Dashboard öffnen und die Stations-Messzeiten mit Bvision vergleichen. Fehlende Gefrierpunktwerte bleiben fehlend.
2. Den PC vollständig herunterfahren. Nach mindestens 20 Minuten auf dem iPhone neu prüfen. Der Messzeitpunkt muss weitergelaufen sein, sofern Boschung neue Messungen bereitstellt. Die Erweiterung liest und überträgt alle 15 Minuten; sie erzeugt keine neuen Messungen.
3. Den Container kontrolliert neu starten. Prüfen, ob Browser, Erweiterung, Anmeldung und die Spaltenübersicht wieder vorhanden sind. Danach erneut die Übertragung bei ausgeschaltetem PC prüfen. Der Startaufruf öffnet die Bvision-Spaltenübersicht; falls Bvision die Sitzung beendet hat, muss man sich erneut anmelden.
4. Erst nach diesen Prüfungen als laufenden NAS-Betrieb betrachten. Ältere Messwerte werden im Dashboard nach 20 Minuten als veraltet markiert. Eine abgelaufene Anmeldung, fehlende Stationen oder ein gestoppter Container können keine aktuellen Messwerte liefern.

Updates des Browser-Images gezielt durchführen und danach den Neustarttest wiederholen. Nicht unbeaufsichtigt ein Image austauschen. Das Paket kann eine erneute Anmeldung bei abgelaufener Bvision-Sitzung oder eine geänderte Bvision-Seitenstruktur nicht verhindern. Es umgeht keine Anmeldung und keine Zugriffssperre.

## Grundlage

LinuxServer Chromium: https://docs.linuxserver.io/images/docker-chromium/

QNAP Container Station: https://www.qnap.com/en/software/container-station

Erstellt am 22.10.2026. Kein Zugriff auf dein NAS erfolgt; Container-Start, Bildschirmanzeige und Dauerbetrieb müssen vor Ort bestätigt werden.
