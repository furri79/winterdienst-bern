# QNAP-Messwertbrücke: Meikirch und Gamsenbrücke Principal

Diese separate Erweiterung liest ausschliesslich die Boschung-Messstellen «Meikirch» und «Gamsenbrücke Principal». Letztere ist die gewählte Referenzstation für Blatten bei Naters. Gampel ist kein Alias und wird nicht eingelesen. Die Bern-Messstellen werden von dieser Variante nicht gelesen. Die echte Boschung-Stationskennung wird aus der sichtbaren Karte übernommen. Keine erfundenen Stationskennungen oder Ersatzmesswerte.

## Bestehenden NAS-Browser verwenden

1. Im Dashboard unter «Administratorenbereich → PC / NAS → Dashboard verbinden» die separate Erweiterung herunterladen.
2. ZIP entpacken. Den Ordner «meikirch-gamsen» mit manifest.json und den JavaScript-Dateien auf dem NAS unter `/share/Container/tsb-bvision/extension/meikirch-gamsen` ablegen. Falls der bestehende Einrichtungsordner anders heisst, dessen Unterordner «extension» verwenden. Die bestehende Bern-Erweiterung nicht überschreiben.
3. Im Chromium auf dem NAS `chrome://extensions` öffnen. Entwicklermodus aktivieren, «Entpackte Erweiterung laden» und `/opt/tsb-extension/meikirch-gamsen` auswählen. Dieser Pfad ist über die vorhandene Ordnerfreigabe des Standard-QNAP-Pakets zugänglich. Bei einer anderen Container-Freigabe den dort eingebundenen Pfad verwenden.
4. Der neue Eintrag heisst «Winterdienst QNAP · Meikirch + Gamsenbrücke». Die Bern-Brücke darf unabhängig weiterlaufen. Es ist kein zusätzlicher Browser-Container nötig.
5. In Boschung anmelden, «Station Mosaik → Spalten» und Filter «Alle» wählen. Beide Messstellen müssen als sichtbare Karten vorhanden sein. Falls nötig, mehrere angemeldete Boschung-Tabs öffnen. Die Erweiterung führt deren Messwerte zusammen und verwendet pro Station die neueste Messzeit. Tabs offen lassen.
6. Im selben NAS-Browser das Dashboard öffnen, mit dem Hauptadministratorkonto anmelden, ganz unten «Administratorenbereich → PC / NAS → Dashboard verbinden → Übertragung aktivieren» wählen. Bestätigung abwarten. Boschung und Dashboard nach einer Neuinstallation einmal neu laden.

## Neueinrichtung ohne bestehenden NAS-Browser

Das komplette Einrichtungspaket enthält «einrichtung.html», diese Anleitung und den Ordner «extension». Unter `/share/Container/meikirch-gamsen` ablegen. «einrichtung.html» lokal auf dem PC öffnen. Lokale NAS-IP, Ordnerpfad und ein eigenes Browser-Passwort mit mindestens 16 Zeichen eingeben. Die Vorlage wird lokal erstellt und enthält keine Boschung-Anmeldedaten.

In Container Station eine Anwendung «meikirch-gamsen» mit der erzeugten Vorlage erstellen. Das Browser-Image stammt von LinuxServer. Die Oberfläche ist nur an die eingegebene lokale NAS-IP gebunden: `https://NAS-IP:3082`. Benutzer «winterdienst». Keine Router-Portfreigabe einrichten. Auf dem bekannten NAS mit 2 GB RAM nur einen Chromium-Container betreiben. Wenn möglich 1024 MB RAM und einen CPU-Kern in den erweiterten Container-Einstellungen setzen; diese Optionen stehen aus Kompatibilitätsgründen nicht in der YAML.

Im NAS-Chromium muss «Winterdienst QNAP · Meikirch + Gamsenbrücke» geladen sein. Falls nötig, unter `chrome://extensions` den Ordner `/opt/tsb-extension` als entpackte Erweiterung laden. Danach wie oben bei Boschung anmelden und die Übertragung im Dashboard aktivieren.

## Prüfen und betreiben

Die Brücke liest und überträgt alle 15 Minuten. Das Dashboard prüft online jede Minute. Die Quellenanzeige wird nur bei einer gültigen Messzeit bis höchstens 20 Minuten grün. Ältere oder unvollständige Temperaturwerte lösen keinen Abstandsalarm aus. Fehlende Gefrierpunkte bleiben fehlend; sie werden nie durch 0 °C ersetzt.

Im Dashboard Meikirch und Blatten bei Naters wählen und jeweils Stationsname, Messzeit und Werte mit Boschung vergleichen. PC ausschalten, NAS eingeschaltet lassen und nach mindestens 20 Minuten erneut prüfen. Anschliessend einen kontrollierten Container-Neustart prüfen. Erst wenn die Messzeiten weiterlaufen, ist der Dauerbetrieb bestätigt.

Die Erweiterung ist geprüft und vorbereitet. Installation, tatsächliche Boschung-Werte und Dauerbetrieb auf deinem NAS konnten hier nicht geprüft werden. Bei abgelaufener Boschung-Anmeldung erneut im NAS-Browser anmelden. Bei fehlenden Stationsrechten werden keine Werte erfunden.

Das persistente Browserprofil enthält private Anmeldungen. Nicht öffentlich freigeben, nicht hier hochladen und beim Aktualisieren nicht löschen. Es werden ausschliesslich freigegebene Stationsmesswerte übertragen, keine Boschung-Passwörter, Cookies oder Sitzungsschlüssel ausgelesen.
