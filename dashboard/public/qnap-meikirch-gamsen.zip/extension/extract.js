// Read only visible station DOM. Never read forms, cookies or browser storage.
function tsbExtract(doc, now = new Date()) {
  const ids = {};
  const names={gamsenbruecke:'Gamsenbrücke Principal',meikirch:'Meikirch'};
  const namedLinks={};
  const normalize=s=>String(s||'').normalize('NFC').trim().replace(/\s+/g,' ').toLocaleLowerCase('de-CH');
  for(const link of doc.querySelectorAll('a[href^="#/map/station-history/"]')){
    const card=link.closest('[class*="_overview_"]');
    if(!card||card.getClientRects().length===0)continue;
    for(const [key,name] of Object.entries(names)){
      const matches=[link,...card.querySelectorAll('*')].some(node=>normalize(node.textContent)===normalize(name));
      const id=link.getAttribute('href')?.match(/^#\/map\/station-history\/(\d{1,32})$/)?.[1];
      if(matches&&id){
        // Ambiguous duplicate station names are rejected instead of guessing.
        if(namedLinks[key]&&ids[key]!==id){ids[key]=null;namedLinks[key]=false;}
        else if(namedLinks[key]!==false){ids[key]=id;namedLinks[key]=link;}
      }
    }
  }
  const parts = Object.fromEntries(new Intl.DateTimeFormat('en-CA',{timeZone:'Europe/Zurich',year:'numeric',month:'2-digit',day:'2-digit'}).formatToParts(now).map(p=>[p.type,p.value]));
  function stamp(raw){
    const m=raw.match(/(\d{2})\.(\d{2})\.,?\s*(\d{2}):(\d{2})/);
    if(!m) return null;
    let year=Number(parts.year);
    if(Number(parts.month)===1 && Number(m[2])===12) year--;
    const wall=Date.UTC(year,+m[2]-1,+m[1],+m[3],+m[4]);
    let instant=wall;
    for(let i=0;i<2;i++){
      const off=new Intl.DateTimeFormat('en',{timeZone:'Europe/Zurich',timeZoneName:'shortOffset'}).formatToParts(new Date(instant)).find(p=>p.type==='timeZoneName').value;
      const match=off.match(/GMT([+-])(\d{1,2})(?::(\d{2}))?/);
      const minutes=match ? (match[1]==='-'?-1:1)*(+match[2]*60+ +(match[3]||0)) : 0;
      instant=wall-minutes*60000;
    }
    if(instant>now.getTime()+300000) return null;
    return new Date(instant).toISOString();
  }
  const number=s=>{
    const t=s.trim().replace(',','.');
    return /^-?\d+(?:\.\d+)?$/.test(t) ? Number(t) : null;
  };
  const stations={};
  for(const [key,id] of Object.entries(ids)){
    if(!id)continue;
    const link=namedLinks[key]||doc.querySelector('a[href="#/map/station-history/'+id+'"]');
    const card=link?.closest('[class*="_overview_"]');
    if(!card || card.getClientRects().length===0) continue;
    const values=Array.from(card.querySelectorAll('[class*="_sensorValue_"]')).map(e=>e.textContent);
    const rawTime=card.querySelector('[class*="_timestamp_"]')?.textContent || '';
    const icons=Array.from(card.querySelectorAll('svg[title]')).map(e=>e.getAttribute('title'));
    const condition=icons.find(t=>/^(?:Fahrbahn |Trocken$|Nass$|Feucht$|Eis|Schnee|Reif|Glatt)/i.test(t)) || null;
    const observed=stamp(rawTime);
    if(values.length!==4 || !observed) continue;
    stations[key]={station_id:id,...(names[key]?{station_name:names[key]}:{}),observed_at:observed,air_temperature_c:number(values[0]),road_temperature_c:number(values[1]),freezing_point_c:number(values[2]),relative_humidity_pct:number(values[3]),road_condition:condition};
  }
  return {updated_at:now.toISOString(),stations};
}
if(typeof module!=='undefined') module.exports={tsbExtract};
